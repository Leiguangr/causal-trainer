export { prisma } from './db';

